# Habilitar cuenta Administrador
Get-LocalUser -Name "Administrador" | Enable-LocalUser

# Asignar contraseña a Administrador
$Password = ConvertTo-SecureString "20Xxvti!" -AsPlainText -Force
$UserAccount = Get-LocalUser -Name "Administrador"
$UserAccount | Set-LocalUser -Password $password

# Añadir CyD a Grupo estándar
Add-LocalGroupMember -Group "Usuarios" -Member "CyD"
Remove-LocalGroupMember -Group "Administradores" -Member "CyD"

# Reiniciar el equipo
Restart-Computer