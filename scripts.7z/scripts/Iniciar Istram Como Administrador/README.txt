Este script es exclusivamente para ejecutar Istram con permisos de administrador, con el fin de facilitar al usuario actualizar el programa sin tener que acudir a TI para que coloque la contraseña de administrador.

Si no ha ejecutado nunca estos scripts, el primero que debe ejecutar es "guardar_credenciales.bat".
Una vez lo haya ejecutado, no necesitará volver a hacerlo.

Cada vez que quiera ejecutar Istram como administrador para poder actualizarlo, en lugar de abrirlo como normalmente hace, debe hacerlo con "ejecutar_istram.bat".

Cada vez que ejecute el programa es posible que se cree un archivo llamado "comandos.fc". Eso ocurre sólo porque lo está haciendo por medio de un script, pero no hace nada.

No saque los scripts de la carpeta porque funcionan gracias a archivos ocultos.