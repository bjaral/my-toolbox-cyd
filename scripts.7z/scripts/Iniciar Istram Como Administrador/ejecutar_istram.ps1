$User = "Administrador"
$Password = Get-Content "C:\ProgramData\cred.txt" | ConvertTo-SecureString
$Cred = New-Object System.Management.Automation.PSCredential($User, $Password)
Start-Process "C:\Ispol\util\Arranque.exe" -Credential $Cred -NoNewWindow