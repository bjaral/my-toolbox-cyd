Estos scripts son para solucionar el problema si un colaborador trabaja en dos oficinas con el mismo nombre de red (CyD). Sólo funcionarán si la persona ya se ha conectado anteriormente a la red. Las contraseñas están encriptadas.

Si no ha ejecutado estos scripts, las instrucciones son las siguientes:

1. Ejecutar "conectar_wifi_red_1" para crear y conectarse a la red 1
2. Ejecutar "conectar_wifi_red_2" para crear y conectarse a la red 2