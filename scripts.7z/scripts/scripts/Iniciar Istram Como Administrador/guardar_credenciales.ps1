$cred = Get-Credential
$cred.Password | ConvertFrom-SecureString | Set-Content "C:\ProgramData\cred.txt"