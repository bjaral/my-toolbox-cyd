Este script es para habilitar al usuario "Administrador", establecerle la contraseña corporativa y asignar al usuario "CyD" el grupo de usuarios estándar.

El acceso directo es únicamente para no tener que darle click derecho -> ejecutar como administrador.

Por orden, los scripts principales están en oculto.

Por seguridad, el script "configuracion_usuarios.ps1", que es el que hace todo, en $Passwords hay unas comillas vacías. Dentro se debe colocar la contraseña que se establecerá al equipo. Por ejemplo, si la contraseña fuera 1234, la línea se vería así:

$Password = ConvertTo-SecureString "1234" -AsPlainText -Force

Si el script se ejecuta más de una vez sólo saldrán errores en la terminal, pero no hará nada en el equipo.