# Define ruta de "Archivos de Programa"
$path = "C:\Program Files"

# Acl es access control list, por lo que obtiene los permisos de la carpeta
$acl = Get-Acl -Path $path

# Deniega permisos de lectura a los usuarios estándar
$rule = New-Object System.Security.AccessControl.FileSystemAccessRule("Usuarios","Read","ContainerInherit,ObjectInherit","None","Deny")

# Aplica la regla al acl de program files
$acl.SetAccessRule($rule)

# Aplica el acl con las nuevas reglas a program files
Set-Acl -Path $folderPath -AclObject $acl