Estos scripts son para solucionar el problema si un colaborador trabaja en dos oficinas con el mismo nombre de red (CyD). Sólo funcionarán si la persona ya se ha conectado anteriormente a la red. Las contraseñas están encriptadas.

Si no ha ejecutado estos scripts, las instrucciones son las siguientes:

Primero, asegúrese de tener en C:\ (La carpeta Disco Local) creada una carpeta con el nombre "WifiProfiles". Si no la tiene, la puede crear manualmente o ejecutando el script "crear_carpeta_wifi_profiles".

En la primera red que se encuentre, ejecute "crear_xml_red_1". Esto creará en su computador el perfil de la red en la que se encuentra y le asignará el apodo "Wi-Fi-CyD-Red-1".

En la segunda red, ejecute "crear_xml_red_2". Esto creará en su computador el perfil de la red en la que se encuentra y le asignará el apodo "Wi-Fi-CyD-Red-2".

Para conectarse a cada una de las redes, debe ejecutar el script con su respectivo apodo. Por ejemplo, para conectarse a la red 1 debe ejecutar "conectar_wifi_red_1".



Resumen:
1. Ejecutar "crear_carpeta_wifi_profiles"
2. En la primera red, ejecutar "crear_xml_red_1"
3. En la segunda red, ejecutar "crear_xml_red_2"
4. Para conectarse a cualquiera de las dos redes, ocupar el script con su respectivo apodo.